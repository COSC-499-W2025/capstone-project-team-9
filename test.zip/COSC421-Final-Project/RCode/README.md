# R Analysis Code

The code used for the R analysis is provided in the `code.rmd` file. To run the analysis successfully, follow the instructions below:

1. Open the `Code.Rmd` file.
2. Locate the `read.csv()` function on line 7.
3. Update the file path to point to the correct location of the data file in the repository (`DataFiles/RData/drugs_side_effects_drugs_com.csv`) on your system.


Once the file path is updated, the analysis should work as expected.
