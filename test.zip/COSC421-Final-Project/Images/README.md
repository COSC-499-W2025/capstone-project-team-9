Includes the images used for main README.md file. 
